# Wisescape 3D — Projet Android prêt pour GitHub

Ce dépôt compile le jeu HTML/Three.js dans une application Android plein écran.

## Générer l'APK depuis un téléphone avec GitHub

1. Créez un dépôt GitHub nommé `Wisescape3D` (public ou privé).
2. Décompressez cette archive ZIP sur votre téléphone.
3. Dans le dépôt GitHub, faites **Add file → Upload files**.
4. Envoyez tout le contenu du dossier `Wisescape3D_GitHub` : les dossiers `app/` et `.github/` ainsi que les fichiers Gradle à la racine.
5. Vérifiez que `.github/workflows/build-apk.yml` est bien présent à la racine du dépôt.
6. Appuyez sur **Commit changes** sur la branche `main`.
7. Ouvrez l'onglet **Actions**, puis l'exécution **Build Wisescape 3D APK**.
8. Attendez la coche verte. Ouvrez l'exécution et téléchargez l'artefact **Wisescape3D-APK**.
9. Extrayez l'archive téléchargée : elle contient `app-debug.apk`. Ouvrez ce fichier pour installer le jeu.

## À savoir

- Le workflow utilise Java 17 et Gradle 8.9, puis lance `:app:assembleDebug`.
- Android Gradle Plugin signe automatiquement l'APK debug avec une clé de test. Cette version convient à une installation personnelle, pas à une publication Play Store.
- Le jeu charge Three.js depuis `cdnjs.cloudflare.com` : une connexion Internet est nécessaire au démarrage du jeu.
- Pour les mises à jour, gardez le même dépôt et le même mécanisme de compilation/signature.

## Structure attendue à la racine GitHub

- `.github/workflows/build-apk.yml`
- `app/build.gradle`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/assets/index.html`
- `app/src/main/java/com/wisescape/game/MainActivity.java`
- `app/src/main/res/drawable/ic_launcher.xml`
- `build.gradle`
- `settings.gradle`
- `gradle.properties`
